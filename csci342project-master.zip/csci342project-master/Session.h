//
//  Session.h
//  studentHelperApp
//
//  Created by Ryan Toohey on 27/10/13.
//  Copyright (c) 2013 gf99rjda640. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Session : NSObject

@property (retain, nonatomic) NSString *sessionName;
@property double WAM;
@end
