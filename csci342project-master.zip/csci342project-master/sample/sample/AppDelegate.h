//
//  AppDelegate.h
//  sample
//
//  Created by cs321kw1a on 3/10/13.
//  Copyright (c) 2013 rjda60. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
