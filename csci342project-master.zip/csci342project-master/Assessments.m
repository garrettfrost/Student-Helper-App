//
//  Assessments.m
//  studentHelperApp
//
//  Created by cs321kw1a on 21/10/13.
//  Copyright (c) 2013 gf99rjda640. All rights reserved.
//

#import "Assessments.h"
#import "Subjects.h"


@implementation Assessments

@dynamic assID;
@dynamic due;
@dynamic mark;
@dynamic name;
@dynamic weighting;
@dynamic subjectCode;
@dynamic completed;
@dynamic assOwnedBySubject;

@end
