//
//  ViewController.m
//  studentHelperApp
//
//  Created by cs321kw1a on 3/10/13.
//  Copyright (c) 2013 gf99rjda640. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Prepopulate data
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
