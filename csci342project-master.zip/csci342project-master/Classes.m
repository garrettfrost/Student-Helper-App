//
//  Classes.m
//  studentHelperApp
//
//  Created by cs321kw1a on 20/10/13.
//  Copyright (c) 2013 gf99rjda640. All rights reserved.
//

#import "Classes.h"
#import "Subjects.h"


@implementation Classes

@dynamic day;
@dynamic duration;
@dynamic room;
@dynamic time;
@dynamic type;
@dynamic subjectCode;
@dynamic classOwnedBySubject;
@dynamic session;

@end
