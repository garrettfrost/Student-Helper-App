//
//  CurrentSession.h
//  studentHelperApp
//
//  Created by Ryan Toohey on 27/10/13.
//  Copyright (c) 2013 gf99rjda640. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface CurrentSession : NSManagedObject

@property (nonatomic, retain) NSString * currSession;

@end
