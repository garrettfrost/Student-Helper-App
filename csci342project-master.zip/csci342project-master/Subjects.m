//
//  Subjects.m
//  studentHelperApp
//
//  Created by cs321kw1a on 20/10/13.
//  Copyright (c) 2013 gf99rjda640. All rights reserved.
//

#import "Subjects.h"
#import "Assessments.h"
#import "Classes.h"


@implementation Subjects

@dynamic completed;
@dynamic creditPoints;
@dynamic mark;
@dynamic name;
@dynamic session;
@dynamic subjectCode;
@dynamic assessmentRelationship;
@dynamic classesRelationship;

@end
