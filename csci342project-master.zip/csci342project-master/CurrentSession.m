//
//  CurrentSession.m
//  studentHelperApp
//
//  Created by Ryan Toohey on 27/10/13.
//  Copyright (c) 2013 gf99rjda640. All rights reserved.
//

#import "CurrentSession.h"


@implementation CurrentSession

@dynamic currSession;

@end
